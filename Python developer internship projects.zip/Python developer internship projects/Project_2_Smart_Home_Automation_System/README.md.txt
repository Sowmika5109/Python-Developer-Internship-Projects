# Smart Home Automation System - Python Developer Internship Project

This is a simple Smart Home Automation System using Python and Flask.
It simulates controlling smart home devices like Light, Fan, and AC.

## How to Run:

1. Install Flask:
   pip install flask

2. Run the project:
   python app.py

3. Open the browser:
   http://127.0.0.1:5000/control?device=light
   http://127.0.0.1:5000/control?device=fan
   http://127.0.0.1:5000/control?device=ac

Each link will toggle the device ON/OFF.
