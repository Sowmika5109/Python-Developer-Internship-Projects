# AI Chatbot Project - Python Developer Internship

This is a simple AI-based chatbot created using Python and FastAPI.

## How to run the project:

1. Install FastAPI:
   pip install fastapi uvicorn

2. Run the app:
   uvicorn app:app --reload

3. Open in browser:
   http://127.0.0.1:8000/chat?message=Hello

This will show the chatbot response.
